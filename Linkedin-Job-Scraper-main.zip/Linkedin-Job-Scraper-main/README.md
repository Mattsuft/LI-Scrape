# Linkedin-Job-Scraper
Job postings scraper for linkedin using python + requests + BS4
